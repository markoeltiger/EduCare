package com.example.educare.Model;

public class Course {
    private String CourseName;
    public Course(String coursename){
        CourseName=coursename;
    }
    public void setCourseName(String CourseName) {
        this.CourseName = CourseName;
    }

    public String getCourseName() {
        return CourseName;
    }

}
