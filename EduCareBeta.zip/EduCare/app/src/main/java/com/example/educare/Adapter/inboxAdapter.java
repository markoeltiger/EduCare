package com.example.educare.Adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.educare.Model.Chat;
import com.example.educare.Model.Users;
import com.example.educare.R;

import java.util.List;

public class inboxAdapter extends RecyclerView.Adapter {
    List<Chat> myUsersList;

    public inboxAdapter(List<Chat> mUsersList) {
        this.myUsersList = mUsersList;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.list_senders_item,parent,false);
        MessageViewHolder viewHolderClass=new MessageViewHolder(view);

        return viewHolderClass;
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        MessageViewHolder viewHolderClass =(MessageViewHolder) holder;

        Chat users =myUsersList.get(position);

        viewHolderClass.sender.setText(users.getSender().toString());
        viewHolderClass.message.setText(users.getMessage().toString());


    }

    @Override
    public int getItemCount() {
        return myUsersList.size();
    }


}
