package com.example.educare.Model;

import java.util.Date;

public class Chat {
      private String sender,message;

      public Chat(String message, String sender, Date date){
          this.message = message;

          this.sender = sender;

      }

    public Chat() {
    }

    public String getSender() {
        return sender;
    }

    public void setSender(String sender) {
        this.sender = sender;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getUid() {
        return sender;
    }

    public void setUid(String uid) {
        this.sender = uid;
    }


}

