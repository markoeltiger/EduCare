package com.example.educare;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.SharedPreferences;
import android.os.Bundle;

import com.example.educare.Adapter.CourseAdapter;
import com.example.educare.Adapter.inboxAdapter;
import com.example.educare.Model.Chat;
import com.example.educare.Model.Course;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class inbox extends AppCompatActivity {
    String ReciverName;
RecyclerView recyclerView;
    List<Chat> myCourseList;
    DatabaseReference databaseReference;
    inboxAdapter inboxAdapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inbox);
        recyclerView=findViewById(R.id.recyInbox);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        myCourseList=new ArrayList<>();
        SharedPreferences sh = getSharedPreferences("MyPrefs", MODE_PRIVATE);
        ReciverName=sh.getString("nameKey","Mark");
        databaseReference= FirebaseDatabase.getInstance().getReference("Users").child("Student").child(ReciverName).child("Chats");
        databaseReference.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for(DataSnapshot  ds:snapshot.getChildren()){

                    Chat course =ds.getValue(Chat.class);
                    myCourseList.add(course);
                }
                inboxAdapter=new inboxAdapter(myCourseList);
                recyclerView.setAdapter(inboxAdapter);
            }
            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }
}