package com.example.educare.Adapter;

import android.view.View;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.educare.R;

public class MessageViewHolder extends RecyclerView.ViewHolder{
    TextView sender,message,Date ;
    public MessageViewHolder(@NonNull View itemView) {
        super(itemView);
        sender=itemView.findViewById(R.id.sender_name);
        message=itemView.findViewById(R.id.sender_message);

    }
    @Override
    public String toString() {
        return super.toString();
    }
}
