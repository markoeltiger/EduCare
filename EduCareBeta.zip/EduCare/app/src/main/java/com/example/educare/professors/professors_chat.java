package com.example.educare.professors;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;

import com.example.educare.R;
import com.example.educare.inbox;
import com.example.educare.student.chattingpagestudent;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class professors_chat extends AppCompatActivity {
RecyclerView recyclerView;
FloatingActionButton messageIcon;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.pof_chat);

        recyclerView=(RecyclerView)findViewById(R.id.rey_profChat);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        BottomNavigationView bottomNavigationViewprof=findViewById(R.id.bottom_navigationprof);
        bottomNavigationViewprof.setSelectedItemId(R.id.professor_chat);
        bottomNavigationViewprof.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch (item.getItemId()){

                    case R.id.professor_chat:
                        return true;
                    case R.id.prfessor_student:
                        startActivity(new Intent(getApplicationContext(),professors.class));
                        return true;
                    case R.id.materials:
                        startActivity(new Intent(getApplicationContext(), materials.class));
                        return true;
                }
                return false;
            }
        });
        messageIcon=findViewById(R.id.message_icon);
        messageIcon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(professors_chat.this, inbox.class);
                startActivity(intent);
            }
        });
    }
}