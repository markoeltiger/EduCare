package com.example.educare;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;

import java.util.ArrayList;


    public class StudentAdapter extends ArrayAdapter<Student> {
        private int mColorResourceId;

        public StudentAdapter(Context context, ArrayList<Student> students, int ColorResourceId) {
            super(context, 0, students);
            mColorResourceId=ColorResourceId;
        }
        @NonNull

        @Override
        public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
            View listItemView = convertView;
            if (listItemView == null) {
                listItemView = LayoutInflater.from(getContext()).inflate(
                        R.layout.list_item, parent, false);
            }

            Student SingleWord = getItem (position);

            TextView studentTextView = (TextView) listItemView.findViewById(R.id.item_name);


            studentTextView.setText(SingleWord.getStudentName());


            // Set the theme color for the list item
            View textContainer = listItemView.findViewById(R.id.item_name);
            // Find the color that the resource ID maps to
            int color = ContextCompat.getColor(getContext(), mColorResourceId);
            // Set the background color of the text container View
            textContainer.setBackgroundColor(color);

            return listItemView;
        }
    }

