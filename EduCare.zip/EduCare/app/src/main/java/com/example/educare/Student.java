package com.example.educare;

public class Student {
    private String StudentName;
    public Student(String coursename){
        StudentName=coursename;
    }
    public void setStudentName(String CourseName) {
        this.StudentName = CourseName;
    }

    public String getStudentName() {
        return StudentName;
    }

}

