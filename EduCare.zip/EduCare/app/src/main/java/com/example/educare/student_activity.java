package com.example.educare;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.ListView;

import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.util.ArrayList;

public class student_activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_all);

        BottomNavigationView bottomNavigationView=findViewById(R.id.bottom_navigation);
        bottomNavigationView.setSelectedItemId(R.id.student);
        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch (item.getItemId()){

                    case R.id.student:
                        return true;
                    case R.id.courses:
                        startActivity(new Intent(getApplicationContext(), courses_activity.class));
                        return true;
                    case R.id.chats:
                        startActivity(new Intent(getApplicationContext(), chat_activity.class));
                        return true;
                }



                return false;
            }
        });
        final ArrayList<Student> students = new ArrayList<Student>();
        students.add(new Student("loly"));



        StudentAdapter adapter = new StudentAdapter(this, students,R.color.category_student);

        ListView No_students = (ListView) findViewById(R.id.list_co);
        No_students.setAdapter(adapter);




    }

}