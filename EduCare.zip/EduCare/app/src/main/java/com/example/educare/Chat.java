package com.example.educare;

public class Chat {
        private String ChatName;
        public Chat(String chateName){
            ChatName=chateName;
        }
        public void setChatName(String CourseName) {
            this.ChatName = ChatName;
        }

        public String getChatName() {
            return ChatName;
        }

    }

